<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Pterodactyl\Models\ApiKey;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Services\Acl\Api\AdminAcl;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Api\KeyCreationService;
use Pterodactyl\Http\Requests\Admin\Api\StoreApplicationApiKeyRequest;

class ApiController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private KeyCreationService $keyCreationService,
    ) {
        // Tambahkan middleware di constructor
        $this->middleware(function ($request, $next) {
            $user = $request->user();
            
            if (!$user || !$user->root_admin) {
                abort(403, 'Akses ditolak: Hanya admin yang dapat mengakses halaman ini.');
            }
            
            return $next($request);
        });
    }

    public function index(Request $request): View
    {
        $user = $request->user();
        
        // SEMUA admin hanya melihat API key miliknya sendiri
        $keys = ApiKey::query()
            ->where('key_type', ApiKey::TYPE_APPLICATION)
            ->where('user_id', $user->id)
            ->with('user')
            ->get();

        return view('admin.api.index', [
            'keys' => $keys,
            'isAdmin' => $user->root_admin,
        ]);
    }

    public function create(): View
    {
        $user = auth()->user();
        
        // Ambil daftar resources untuk permission
        $resources = AdminAcl::getResourceList();
        sort($resources);
        
        // Semua user hanya bisa membuat untuk dirinya sendiri
        $users = collect([$user]);

        return view('admin.api.new', [
            'resources' => $resources,
            'permissions' => [
                'r' => AdminAcl::READ,
                'rw' => AdminAcl::READ | AdminAcl::WRITE,
                'n' => AdminAcl::NONE,
            ],
            'users' => $users,
            'isAdmin' => $user->root_admin,
        ]);
    }

    public function store(StoreApplicationApiKeyRequest $request): RedirectResponse
    {
        $user = $request->user();
        
        // PAKSA user_id = current user
        $targetUserId = $user->id;
        
        $this->keyCreationService->setKeyType(ApiKey::TYPE_APPLICATION)->handle([
            'memo' => $request->input('memo'),
            'user_id' => $targetUserId,
        ], $request->getKeyPermissions());

        $this->alert->success('API Key baru berhasil dibuat.')->flash();
        return redirect()->route('admin.api.index');
    }

    public function delete(Request $request, string $identifier): Response
    {
        $user = $request->user();
        
        $key = ApiKey::query()
            ->where('key_type', ApiKey::TYPE_APPLICATION)
            ->where('identifier', $identifier)
            ->where('user_id', $user->id)  // PASTIKAN milik sendiri
            ->firstOrFail();

        $key->delete();
        return response('', 204);
    }
}