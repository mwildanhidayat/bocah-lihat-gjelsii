<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Pterodactyl\Models\ApiKey;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Services\Acl\Api\AdminAcl;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Api\KeyCreationService;
use Pterodactyl\Http\Requests\Admin\Api\StoreApplicationApiKeyRequest;

class ApiController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private KeyCreationService $keyCreationService,
    ) {
    }

    public function index(Request $request): View
    {
        $user = $request->user();
        
        // Admin ID 1 bisa melihat semua API key
        if ($user && $user->id === 1) {
            $keys = ApiKey::query()
                ->where('key_type', ApiKey::TYPE_APPLICATION)
                ->with('user')
                ->get();
        } else {
            // User biasa hanya melihat API key miliknya sendiri
            $keys = ApiKey::query()
                ->where('key_type', ApiKey::TYPE_APPLICATION)
                ->where('user_id', $user->id)
                ->with('user')
                ->get();
        }

        return view('admin.api.index', [
            'keys' => $keys,
            'isAdmin' => ($user && $user->id === 1),
        ]);
    }

    public function create(): View
    {
        $user = auth()->user();
        
        // Semua user bisa membuat API key, tapi hanya untuk dirinya sendiri
        // Admin ID 1 tetap bisa membuat untuk siapapun melalui form nanti

        $resources = AdminAcl::getResourceList();
        sort($resources);

        return view('admin.api.new', [
            'resources' => $resources,
            'permissions' => [
                'r' => AdminAcl::READ,
                'rw' => AdminAcl::READ | AdminAcl::WRITE,
                'n' => AdminAcl::NONE,
            ],
            'users' => ($user->id === 1) ? \Pterodactyl\Models\User::all() : collect([$user]),
            'isAdmin' => ($user->id === 1),
        ]);
    }

    public function store(StoreApplicationApiKeyRequest $request): RedirectResponse
    {
        $user = $request->user();
        
        // Validasi: user biasa hanya bisa membuat untuk dirinya sendiri
        if ($user->id !== 1 && $request->input('user_id') && $request->input('user_id') != $user->id) {
            abort(403, 'Anda hanya dapat membuat API Key untuk diri sendiri!');
        }

        // Tentukan user_id yang akan digunakan
        $targetUserId = ($user->id === 1 && $request->input('user_id')) 
            ? $request->input('user_id') 
            : $user->id;

        $this->keyCreationService->setKeyType(ApiKey::TYPE_APPLICATION)->handle([
            'memo' => $request->input('memo'),
            'user_id' => $targetUserId,
        ], $request->getKeyPermissions());

        $this->alert->success('API Key baru berhasil dibuat.')->flash();

        return redirect()->route('admin.api.index');
    }

    public function delete(Request $request, string $identifier): Response
    {
        $user = $request->user();
        
        $key = ApiKey::query()
            ->where('key_type', ApiKey::TYPE_APPLICATION)
            ->where('identifier', $identifier)
            ->firstOrFail();

        // Admin ID 1 bisa hapus API key siapapun
        // User biasa hanya bisa hapus API key miliknya sendiri
        if ($user->id !== 1 && $key->user_id !== $user->id) {
            abort(403, 'Anda hanya dapat menghapus API Key milik sendiri!');
        }

        $key->delete();

        return response('', 204);
    }
}