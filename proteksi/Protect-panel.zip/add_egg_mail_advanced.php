<?php
/**
 * Add Egg, Mail, Advanced controllers protection
 * Run via: php /tmp/add_egg_mail_advanced.php
 */

$panelDir = '/var/www/pterodactyl';

// 1. Buat EggController
$eggControllerContent = '<?php

namespace Pterodactyl\Http\Controllers\Admin\Nests;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\EggVariable;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Eggs\EggUpdateService;
use Pterodactyl\Services\Eggs\EggCreationService;
use Pterodactyl\Services\Eggs\EggDeletionService;
use Pterodactyl\Services\Eggs\Sharing\EggExporterService;
use Pterodactyl\Services\Eggs\Sharing\EggImporterService;
use Pterodactyl\Services\Eggs\Variables\VariableUpdateService;
use Pterodactyl\Http\Requests\Admin\Egg\EggFormRequest;
use Pterodactyl\Http\Requests\Admin\Egg\EggVariablesFormRequest;
use Pterodactyl\Contracts\Repository\EggRepositoryInterface;
use Pterodactyl\Contracts\Repository\NestRepositoryInterface;
use Pterodactyl\Exceptions\DisplayException;

class EggController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected EggCreationService $creationService,
        protected EggDeletionService $deletionService,
        protected EggExporterService $exporterService,
        protected EggImporterService $importerService,
        protected EggRepositoryInterface $repository,
        protected EggUpdateService $updateService,
        protected NestRepositoryInterface $nestRepository,
        protected VariableUpdateService $variableUpdateService
    ) {
        $this->middleware(function ($request, $next) {
            $user = Auth::user();
            
            if (!$user || $user->id !== 1) {
                abort(403, \'Akses ditolak: Hanya Admin ID 1 yang dapat mengakses halaman ini! ©Protect By @WiL Official\');
            }
            
            return $next($request);
        });
    }

    public function create(int $nest): View
    {
        return view(\'admin.nests.eggs.new\', [
            \'nest\' => $this->nestRepository->getWithEggs($nest),
        ]);
    }

    public function store(EggFormRequest $request, int $nest): RedirectResponse
    {
        $egg = $this->creationService->handle($request->normalize(), $nest);
        $this->alert->success(\'Egg was created successfully.\')->flash();

        return redirect()->route(\'admin.nests.egg.view\', [
            \'nest\' => $nest,
            \'egg\' => $egg->id,
        ]);
    }

    public function view(int $nest, int $egg): View
    {
        return view(\'admin.nests.eggs.view\', [
            \'egg\' => $this->repository->getWithData($egg),
            \'nest\' => $this->nestRepository->getWithEggs($nest),
        ]);
    }

    public function update(EggFormRequest $request, int $nest, int $egg): RedirectResponse
    {
        $data = $request->normalize();
        if (isset($data[\'copy_script_from\']) && $data[\'copy_script_from\'] == $nest) {
            $data[\'copy_script_from\'] = null;
        }

        $this->updateService->handle($egg, $data);
        $this->alert->success(\'Egg was updated successfully.\')->flash();

        return redirect()->route(\'admin.nests.egg.view\', [
            \'nest\' => $nest,
            \'egg\' => $egg,
        ]);
    }

    public function variables(int $nest, int $egg): View
    {
        return view(\'admin.nests.eggs.variables\', [
            \'egg\' => $this->repository->getWithData($egg),
        ]);
    }

    public function updateVariables(EggVariablesFormRequest $request, int $nest, int $egg): RedirectResponse
    {
        $this->variableUpdateService->handle($egg, $request->normalize());
        $this->alert->success(\'Egg variables were updated successfully.\')->flash();

        return redirect()->route(\'admin.nests.egg.variables\', [
            \'nest\' => $nest,
            \'egg\' => $egg,
        ]);
    }

    public function export(int $nest, int $egg): RedirectResponse
    {
        $response = response($this->exporterService->handle($egg), 200, [
            \'Content-Type\' => \'application/json\',
            \'Content-Disposition\' => \'attachment; filename="\' . Egg::query()->findOrFail($egg)->name . \'.json"\',
        ]);

        $this->alert->success(\'Egg was exported successfully.\')->flash();

        return $response;
    }

    public function destroy(int $nest, int $egg): RedirectResponse
    {
        $this->deletionService->handle($egg);
        $this->alert->success(\'Egg was deleted successfully.\')->flash();

        return redirect()->route(\'admin.nests.view\', $nest);
    }
}';

file_put_contents($panelDir . '/app/Http/Controllers/Admin/Nests/EggController.php', $eggControllerContent);
echo "✓ EggController.php created\n";

// 2. Buat MailController
$mailControllerContent = '<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Http\Requests\Admin\Settings\MailSettingsFormRequest;

class MailController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private ViewFactory $view
    ) {
        $this->middleware(function ($request, $next) {
            $user = Auth::user();
            
            if (!$user || $user->id !== 1) {
                abort(403, \'Akses ditolak: Hanya Admin ID 1 yang dapat mengakses pengaturan Mail! ©Protect By @WiL Official\');
            }
            
            return $next($request);
        });
    }

    public function index(): View
    {
        return $this->view->make(\'admin.settings.mail\');
    }

    public function update(MailSettingsFormRequest $request): RedirectResponse
    {
        foreach ($request->normalize() as $key => $value) {
            if (!is_null($value)) {
                $this->settings->set(\'settings::\' . $key, $value);
            }
        }

        $this->kernel->call(\'queue:restart\');
        $this->alert->success(\'Mail settings were updated successfully and the queue worker was restarted.\')->flash();

        return redirect()->route(\'admin.settings.mail\');
    }

    public function test(Request $request): RedirectResponse
    {
        $this->alert->success(\'Test email functionality is not implemented in this protected version.\')->flash();
        return redirect()->route(\'admin.settings.mail\');
    }
}';

file_put_contents($panelDir . '/app/Http/Controllers/Admin/Settings/MailController.php', $mailControllerContent);
echo "✓ MailController.php created\n";

// 3. Buat AdvancedController
$advancedControllerContent = '<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Http\Requests\Admin\Settings\AdvancedSettingsFormRequest;

class AdvancedController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private ViewFactory $view
    ) {
        $this->middleware(function ($request, $next) {
            $user = Auth::user();
            
            if (!$user || $user->id !== 1) {
                abort(403, \'Akses ditolak: Hanya Admin ID 1 yang dapat mengakses Advanced Settings! ©Protect By @WiL Official\');
            }
            
            return $next($request);
        });
    }

    public function index(): View
    {
        return $this->view->make(\'admin.settings.advanced\');
    }

    public function update(AdvancedSettingsFormRequest $request): RedirectResponse
    {
        foreach ($request->normalize() as $key => $value) {
            $this->settings->set(\'settings::\' . $key, $value);
        }

        $this->kernel->call(\'queue:restart\');
        $this->alert->success(\'Advanced settings were updated successfully and the queue worker was restarted.\')->flash();

        return redirect()->route(\'admin.settings.advanced\');
    }
}';

file_put_contents($panelDir . '/app/Http/Controllers/Admin/Settings/AdvancedController.php', $advancedControllerContent);
echo "✓ AdvancedController.php created\n";

// 4. Update sidebar protection
$sidebarFile = $panelDir . '/resources/views/layouts/admin.blade.php';
$sidebarContent = file_get_contents($sidebarFile);

// Tambahkan proteksi untuk Mail
$sidebarContent = preg_replace(
    '/([ \t]*<li[^>]*>\s*<a href="{{ route\(\'admin\.settings\.mail\'\) }}".*?<\/li>)/s',
    "@if(Auth::user()->id == 1)\n$1\n@endif {{-- Protect By @WiL --}}",
    $sidebarContent,
    1
);

// Tambahkan proteksi untuk Advanced
$sidebarContent = preg_replace(
    '/([ \t]*<li[^>]*>\s*<a href="{{ route\(\'admin\.settings\.advanced\'\) }}".*?<\/li>)/s',
    "@if(Auth::user()->id == 1)\n$1\n@endif {{-- Protect By @WiL --}}",
    $sidebarContent,
    1
);

file_put_contents($sidebarFile, $sidebarContent);
echo "✓ Sidebar protection updated for Mail and Advanced\n";

echo "\n✅ Semua file proteksi telah ditambahkan!\n";
echo "📍 Hanya Admin ID 1 yang dapat mengakses:\n";
echo "   - /admin/nests/egg/*\n";
echo "   - /admin/settings/mail\n";
echo "   - /admin/settings/advanced\n";